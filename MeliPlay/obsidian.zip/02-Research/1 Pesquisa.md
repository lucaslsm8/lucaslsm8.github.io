# Pesquisa – Competidores e Referências

Análise de outras plataformas para identificar boas práticas e entender como resolver problemas similares.

---

## Objetivo

Estudei apps de streaming e redes sociais para entender como eles resolvem problemas parecidos com os que identifiquei no Meli Play.

---

## Plataformas que Analisei

Foquei minha pesquisa em:
- **Netflix**
- **Amazon Prime Video**
- **Instagram**
- **Meli Play** (mobile e desktop)
- Outros apps de streaming e redes sociais

Também **acessei o aplicativo do Meli Play por mobile e desktop para colher insights** sobre a estrutura atual, navegação e pontos de melhoria.

---

## O que Identifiquei

Ao realizar essa pesquisa, identifiquei **pontos fortes que posso adotar no layout do projeto final**, trazendo assim um aspecto familiar e social para o app.

### Funcionalidades que Vou Implementar

Com base na análise, decidi incluir:

1. **Visualização de recomendações** em um feed dedicado
2. **AI para buscar filmes por metadados** (gênero, atores, cenas específicas)
3. **Gerenciamento de rede pessoal familiar** dentro do app
4. **Perfil personalizado de recomendações** para cada usuário

---

## Como Isso Resolve as Dores das Personas

### Carla (21 anos)
**Dor**: Precisa usar WhatsApp para salvar recomendações

**Minha solução**: Vou criar um sistema para salvar recomendações pessoais dentro do próprio app e permitir compartilhá-las com outros usuários sem sair da plataforma.

---

### Virginia (40 anos)
**Dor**: Não confia em recomendações de algoritmos

**Minha solução**: Vou criar uma rede familiar para que ela veja apenas recomendações de sua família. Ela também poderá receber ou enviar recomendações de familiares ou amigos externos através da função compartilhar.

---

### Roberto (60 anos)
**Dor**: Quer algo simples com recomendações da família em destaque

**Minha solução**: Vou criar uma página de feed familiar que mostrará as recomendações dos membros de sua família. Ele também poderá navegar para perfis pessoais de familiares para ver recomendações específicas deles.

---

### Andrés (30 anos)
**Dor**: Pai esquece nomes de séries que quer recomendar

**Minha solução**: Vou incluir um sistema de AI para busca de metadados. O usuário poderá procurar por gêneros, ou até mesmo descrever uma cena específica do filme e achá-lo no banco de dados de filmes disponíveis.

---

## Pesquisa de Recursos do Mercado Livre

Após decidir como resolveria as dores do usuário, realizei um **webscraping para reunir recursos relacionados com o Mercado Livre e sua marca**, recriando assim boa parte de seu visual e também usando elementos disponíveis na web para facilitar esse processo.

### Recursos que Encontrei

- [Mercado Libre UX no Behance](https://www.behance.net/mercadolibreux)
- [Andes UI - Design System (Behance)](https://www.behance.net/gallery/72037475/Andes-UI?locale=pt_BR)
- [Clon Mercadolibre UI Kit - Figma Community](https://www.figma.com/community/file/1294088629394911922/clon-mercadolibre-ui-kit-andesui-meli-ema-lozada)
- [Como o Mercado Livre escala o design para 100 milhões de compradores na América Latina](https://www.figma.com/pt-br/customers/mercado-libre-scales-design-across-latin-america/)

Esses recursos me ajudaram a:
- Entender o design system do Mercado Livre (Andes UI)
- Ter acesso a componentes prontos para referência
- Manter consistência visual com a marca

---

## Principais Aprendizados

### O que Funcionou Bem em Outras Plataformas

1. **Feed de atividades** (Instagram) - Mantém usuários engajados
2. **Listas personalizadas** (Netflix) - Facilita organização
3. **Compartilhamento integrado** (Apps de streaming) - Reduz fricção
4. **Busca inteligente** (Vários apps) - Ajuda quando usuário não lembra nomes

### Como Vou Aplicar no Meli Play

- **Aspecto familiar e social**: Inspirado em redes sociais mas focado em círculo íntimo
- **Simplicidade**: Inspirado em Netflix mas ainda mais direto e design clean
- **Busca por AI**: Indo além do que streamings atuais oferecem
- **Rede familiar gerenciável**: Algo único que não vi em outros apps

---

← [[2 Personas|Personas]] | [[3 Flowchart|Flowchart →]]
