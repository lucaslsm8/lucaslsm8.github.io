# 📦 Entrega Final – Meli Play UX Challenge

**Data de Entrega**: Outubro 2025
**Projeto**: Solução de Recomendações Familiares para Meli Play
**Designer**: Lucas Schoenherr

---

## 🎯 Resumo Executivo

Este documento consolida todos os entregáveis desenvolvidos para o UX Challenge do Mercado Livre. A solução proposta visa resolver a queda de 4% no uso da plataforma Meli Play através de um sistema inovador de recomendações entre amigos e familiares.

**Problemas identificados**: 
1. Necessidade de apps externos para salvar recomendações.
2.  Baixa confiança em recomendações de algoritmos ou críticos.
3.  Necessidade de uma familiar com recomendações apenas de pessoas próximas.
4. Necessidade de simplicidade e recomendações da família em destaque.

**Solução proposta**: Sistema integrado de recomendações sociais com feed familiar, busca por IA, e perfis personalizados para membros da família e suas recomendações, além de sistemas de compartilhamento interno e externo.

---

## 📋 Entregáveis

### 1. 📊 Apresentação do Projeto

**Formato**: Slide deck completo
**Conteúdo**:
- Análise do problema e contexto do Meli Play
- Pesquisa de usuários e identificação de dores
- Desenvolvimento de personas (Carla, Virginia, Roberto, Andrés)
- Processo de design e tomada de decisões
- Solução proposta com justificativas
- Fluxos de usuário e arquitetura de informação
- Demonstração das telas principais
- Próximos passos e oportunidades futuras

**Objetivo**: Demonstrar o processo de pensamento, decisões de design e como a solução atende às necessidades dos usuários.

---

### 2. 🎨 Arquivo Figma Completo

**Link**: [https://www.figma.com/design/aDA5JnA2ka025SfEmhhNJF/MeliPlay](https://www.figma.com/design/aDA5JnA2ka025SfEmhhNJF/MeliPlay?node-id=0-1&t=l1Qy2K4B6uscbV8x-1)

O arquivo Figma contém toda a documentação visual e interativa do projeto, organizado nas seguintes páginas:

#### 📑 Estrutura do Arquivo

##### **2.1 Pesquisa (Research)**

**Plataformas analisadas:**
- **Netflix**
- **Amazon Prime Video**
- **Instagram**
- **Disney+**
- **Meli Play** (mobile e desktop)

##### **2.2 Flowchart

**Main:** Sessão principal da aplicação, contém a tela de loading e a tela inicial do Meli Play, onde o usuário irá usar o banner para entrar na sessão da família.
**Content:** Usada para exibição de recomendações, visualização de detalhes do conteúdo, compartilhamento e reprodução de vídeo.
**AI Search:** Sessão de procura usando AI para identificar metadados e cruzar referencia com conteúdo procurado pelo usuário, como atores, cenas, nomes, entre outros.
**Settings:** Sessão de Gerenciamento de membros da família, gerenciamento de recomendações, gerenciamento e edição de perfil pessoal.
**About>** Explicativo de conexões



##### **2.3 Wireframes (13 telas)**
**Telas incluídas**:

1. Loading
2. Home Meli Play
3. Recomendações do Usuário Familiar
4. Detalhes do Filme
5. Tela de Reprodução
6. Detalhes do conteúdo
7. Configurações
8. Gerenciamento de rede familiar
9. Perfil do Usuário
10. Recomendação do Usuário


**Foco**: Decisões funcionais, arquitetura de informação, hierarquia de conteúdo

##### **2.4 Low Fidelity**
- Reconstrução da homepage atual do Meli Play, usando AI e Web Scrapping, em preparo para adição do Banner de Família
- Análise da estrutura existente
- Identificação de pontos de melhoria e localização do banner da sessão da família
- Base para comparação com a solução proposta

##### **2.5 High Fidelity (17 telas)

**Telas em alta fidelidade**:
1. Loading
2. Main Page
3. Family Feed
4. Family Feed Profile
5. Family Reccomendations ( Action )
6. Content
7. Play Interface
8. Settings
9. Manage Family
10. Manage Family ( Action )
11. User Profile
12. User Profile ( Action )
13. User Recomendations
14. User Recomendations ( Action )
15. Family Profile
16. Family Profile ( Action )
17. Ai Search

	**NOTA: Nome dos layer mudados para inglês para facilitar entendimento internacional, texto mantido em português**

##### **2.6 Protótipo Interativo**
**Recursos implementados**:
- Navegação completa entre telas
- Animações de transição suaves
- Micro-interações e animações (like, salvar, compartilhar, AI search)
- Modal animations
- Scroll behaviors
- Estados de loading
- Feedback de ações do usuário
- Simulação de busca por IA ( Animação )
- Fluxo de enviar recomendação

##### **2.8 Recursos (Assets)

**Componentes**: Criados cerca de 50 componentes e variantes para uso no programa.

**Materiais extraídos via web scraping**:
- Logos do Mercado Livre (SVG e PNG)
- Ícones do Andes UI Design System
- Imagens de referência da marca
- Paleta de cores oficial
- Grid system
- Tipografia (Inter)
- Ilustrações de marketing
- Screenshots do Meli Play atual
- Elementos de interface existentes

**Fonte dos recursos**:
- [Mercado Libre UX no Behance](https://www.behance.net/mercadolibreux)
- [Andes UI - Design System](https://www.behance.net/gallery/72037475/Andes-UI)
- [Figma Community - Mercado Libre UI Kit](https://www.figma.com/community/file/1294088629394911922)
- Site oficial do Mercado Livre
- Aplicativo Meli Play (mobile e desktop)

---

### 3. 🌐 Página Web de Documentação

**URL**: [https://designbylucas.com/Meliplay](https://designbylucas.com/Meliplay)
**Status**: ✅ Produção (v0.6.1)

#### Características Técnicas

**Tecnologias utilizadas**:
- HTML5 semântico
- CSS3 (Grid, Flexbox, Custom Properties, Animations)
- JavaScript Vanilla (Intersection Observer, Dynamic Particles)
- Google Fonts (Inter)

**Estrutura da página**:

##### **Seções incluídas**:

1. **Header fixo**
   - Logo Mercado Livre
   - Navegação principal
   - Branding amarelo (#ffdd00)

2. **Hero Section**
   - Título principal com destaque "Meli Play"
   - Background azul com gradiente animado
   - 20 partículas flutuantes
   - Stats visuais (17 telas high-fi, 13 wireframes, 50+ componentes, 4 dores solucionadas)
   - CTAs: "Ver Desafio" e "Entregáveis"

3. **Desafio Section**
   - Card explicativo do contexto
   - 4 cards de personas (apenas nome e idade)
   - Identificação das dores dos usuários

4. **A Solução Section**
   - 4 features principais:
     - Feed Familiar
     - Busca por IA
     - Rede Familiar Gerenciável
     - Recomendações Pessoais

5. **Processo Section**
   - 4 etapas do design thinking:
     - 🔍 Pesquisa (Competidores e usuários)
     - 🎯 Definição (Personas e problemas)
     - 💡 Ideação (Soluções e wireframes)
     - ✨ Prototipação (High-fi e testes)

6. **Entregáveis Section**
   - 4 cards com links para:
     - 📄 Apresentação ([Figma Deck](https://www.figma.com/deck/sjnT0dCxple6DzOfiTvM5j/Meli-UX-Challenge---Lucas-Schoenherr))
     - 🎨 Arquivo Figma ([Design File](https://www.figma.com/design/aDA5JnA2ka025SfEmhhNJF/MeliPlay))
     - 🎮 Protótipo Interativo ([Prototype](https://www.figma.com/proto/aDA5JnA2ka025SfEmhhNJF/MeliPlay))
     - 📚 Documentação Obsidian ([Download ZIP](https://designbylucas.com/MeliPlay/obsidian.zip))
   - Logos oficiais das ferramentas
   - Botões de visualização

7. **Obrigado Section**
   - Perfil do designer
   - Mensagem de agradecimento pela oportunidade
   - Links para: Email, LinkedIn, Portfólio
   - Stats profissionais (17 telas, 13 wireframes, 50+ componentes)

8. **Footer**
   - Branding Meli Play UX Challenge
   - Copyright

#### Design System da Landing Page

**Cores**:
- Amarelo ML: #ffdd00
- Azul ML: #3483fa
- Cinza escuro: #333
- Background claro: #fafafa

**Animações**:
- Gradiente animado no hero (8s loop)
- Partículas flutuantes com movimento aleatório
- Float animation nos stats cards (3s)
- Hover effects com elevação nos cards
- Micro-interações nos botões

**Responsividade**:
- ✅ Ultrawide (2560px+)
- ✅ Desktop (1024px-2559px)
- ✅ Tablet (768px-1023px)
- ✅ Mobile (≤767px)

**Acessibilidade**:
- WCAG 2.1 AA compliant
- `prefers-reduced-motion` support
- Estrutura semântica
- Alt texts completos
- Navegação por teclado
- Contraste adequado (AAA)

#### Conteúdo Disponível

**📚 Documentação Obsidian completa**:
- [[1 Desafio|Briefing do challenge]]
- [[1 Pesquisa|Pesquisa e análise competitiva]]
- [[2 Personas|Desenvolvimento de personas]]
- [[3 Flowchart|Fluxos de usuário]]
- [[Documentacao-Geral|Documentação da landing page]]
- [[Logs-Versionamento|Histórico de versões]]

**🎨 Arquivo Figma**:
- [Design completo](https://www.figma.com/design/aDA5JnA2ka025SfEmhhNJF/MeliPlay)
- [Protótipo interativo](https://www.figma.com/proto/aDA5JnA2ka025SfEmhhNJF/MeliPlay)

**📊 Apresentação**:
- [Apresentação Figma Deck](https://www.figma.com/deck/sjnT0dCxple6DzOfiTvM5j/Meli-UX-Challenge---Lucas-Schoenherr?node-id=1-101&viewport=132%2C-165%2C0.75&t=lDze6ftKa4BeesNF-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1)

**📚 Documentação**:
- [Download Vault Obsidian](https://designbylucas.com/MeliPlay/obsidian.zip)

---

## 🎯 Soluções Implementadas

### Resolução das Dores dos Usuários

#### **Carla, 21 anos**
**Dor**: "Tenho uma conversa comigo mesma no WhatsApp para anotar todos os filmes que meus colegas me recomendam."

**Solução**:
- Sistema de salvamento de recomendações dentro do app
- Compartilhamento direto entre usuários sem sair da plataforma
- Recomendação de filmes dentro da família / Amigos

#### **Virginia, 40 anos**
**Dor**: "Eu nunca me guio pelas recomendações de críticos de cinema ou pelas opiniões de pessoas que eu não conheço."

**Solução**:
- Feed exclusivo de recomendações familiares
- Rede familiar gerenciável
- Possibilidade de receber lista de recomendações externas.

#### **Roberto, 60 anos**
**Dor**: "Tecnologia não é o meu forte. Quando abro o Meli Play, gostaria de ter um espaço com os conteúdos destacados pela minha família."

**Solução**:
- Feed familiar em destaque na home
- Navegação simples entre perfis de familiares

#### **Andrés, 30 anos**
**Dor**: "Meu pai sempre esquece o nome das séries que quer me recomendar, e eu acabo tendo que procurar os títulos ou os atores no Google."

**Solução**:
- Busca por IA com metadados
- Descrição de cenas, atores, títulos, entre outros são procurados pela AI e resultados exibidos para o usuário no chat.


---

## 📁 Organização dos Arquivos

### Estrutura do Vault Obsidian

```
MeliPlay/
├── 01-Briefing/
│   └── 1 Desafio.md
├── 02-Research/
│   ├── 1 Pesquisa.md
│   ├── 2 Personas.md
│   └── 3 Flowchart.md
├── 03-Landing-Page/
│   ├── Documentacao-Geral.md
│   ├── Logs-Versionamento.md
│   └── Versions/
│       ├── Versão 0.6.0.md
│       └── Versão 0.6.1.md
├── 04-Resources/
│   ├── 1 References.md
│   └── 2 Emojis Quickacess.md
├── Entrega Final - Meli Play UX Challenge.md (este arquivo)
└── Todo.md
```

---

## 🚀 Próximos Passos

### Recomendações para Implementação e sugestões de funcionalidades novas.

**Fase 1 - MVP
- Implementar feed de recomendações familiares
- - Perfis e recomendações personalizados de usuários
- Compartilhamento de conteúdo

**Fase 2 - Features Avançadas e Novas
- Busca por IA com metadados
- Novo: Fluxo de Adição de Familiar
- Novo: Sistema de notificações contextuais


**Fase 3 - Otimizações 
- Analytics e tracking de uso
- A/B testing de features
- Ajustes baseados em feedback real de usuários.

---

## 📞 Contato

**Designer**: Lucas Schoenherr
**Email**: lucas.schoenherr@gmail.com
**LinkedIn**: [linkedin.com/in/lucas-scho](https://www.linkedin.com/in/lucas-scho/)
**Portfólio**: [designbylucas.com](https://designbylucas.com/)
**Landing Page do Projeto**: [designbylucas.com/Meliplay](https://designbylucas.com/Meliplay)

---