# 🔗 References – Meli Play

Links úteis e referências utilizadas no projeto.

---

## 🎨 Design System & Andes UI

- [Mercado Libre at Figma - Case Study](https://www.figma.com/pt-br/customers/mercado-libre-scales-design-across-latin-america/)
- [Mercado Libre UX no Behance](https://www.behance.net/mercadolibreux)
- [Andes UI - Design System (Behance)](https://www.behance.net/gallery/72037475/Andes-UI?locale=pt_BR)
- [Clon Mercadolibre UI Kit - Figma Community](https://www.figma.com/community/file/1294088629394911922/clon-mercadolibre-ui-kit-andesui-meli-ema-lozada)

---

## 🛠️ Ferramentas Utilizadas

### Design
- **Figma**: https://figma.com
- **Google Fonts - Inter**: https://fonts.google.com/specimen/Inter

### Desenvolvimento
- **Augment Code**: AI coding assistant
- **Claude Code**: VS Code Extension
- **Obsidian**: https://obsidian.md

---

## 🔗 Projeto

### Repositório (Futuro)
- GitHub: [meliplay-ux-challenge](#)

### Landing Page
- URL: [meliplay-ux-challenge.com](#)

---

←  [[04-Under-the-Hood/Overview|Voltar para Under the Hood]]

---

**Última atualização**: Janeiro 2025
