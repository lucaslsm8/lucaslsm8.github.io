# 🎨 Biblioteca de Emojis para Notas do Obsidian

Guia rápido para deixar sua vault mais visual e organizada.
Basta copiar o emoji e colar no início do nome da nota ou pasta.

---

## 🧩 Projetos e Trabalho

🧩 Projeto  
🏗️ Construção  
🛠️ Desenvolvimento  
🚀 Lançamento  
📦 Produto  
💼 Trabalho  
📁 Pasta de Projeto  
🧱 Estrutura  
🧠 Brainstorm  
🗂️ Organização  

---

## 💡 Ideias e Inspirações

💡 Ideia  
✨ Inspiração  
🎨 Design  
🖋️ Conceito  
🧭 Direção  
🎯 Foco  
🔥 Tendência  
🌈 Criatividade  
🌱 Início de projeto  
💭 Reflexão  

---

## 🗓️ Tarefas e Rotina

✅ Tarefa  
☑️ Check  
🕒 Agenda  
📆 Planejamento  
📝 To-do list  
📋 Checklist  
🚧 Em andamento  
🏁 Finalizado  
⚙️ Em progresso  
🔄 Revisão  

---

## 🧠 Estudos e Aprendizado

📘 Estudo  
📚 Leitura  
📖 Anotações  
🧮 Exercício  
🧠 Conhecimento  
🎓 Curso  
🧾 Resumo  
🔍 Pesquisa  
🧰 Ferramentas  
🧑‍🏫 Tutorial  

---

## 📊 Dados, Relatórios e Métricas

📊 Relatório  
📈 Crescimento  
📉 Análise  
📑 Documento  
🧾 Registro  
📋 Métrica  
💹 Indicador  
🧮 Cálculo  
💾 Backup  
🧷 Referência  

---

## 🗃️ Organização e Sistema

📁 Pasta  
🗂️ Arquivo  
🗃️ Banco de dados  
🧱 Template  
📜 Estrutura  
🧾 Registro  
📇 Índice  
🔖 Marcador  
📌 Fixado  
🧩 Seção  

---

## 💬 Comunicação e Feedback

💬 Conversas  
📣 Avisos  
🗣️ Feedback  
📝 Notas rápidas  
📧 Email  
📞 Reunião  
🧑‍💻 Colaboração  
🤝 Alinhamento  
👥 Equipe  
💭 Discussão  

---

## 🧳 Pessoal e Vida

🏠 Casa  
💰 Finanças  
💳 Despesas  
📅 Agenda pessoal  
❤️ Saúde  
🎵 Música  
🎬 Filmes e séries  
🎮 Jogos  
🍽️ Receitas  
🌍 Viagem  

---

## ⚙️ Configurações e Sistema

⚙️ Configuração  
🔧 Ajuste  
🧩 Plugin  
💻 Sistema  
📲 Mobile  
🧱 Estrutura interna  
🔐 Segurança  
🧭 Navegação  
🧩 Integração  

---

## 💎 Extras e Diversos

🌟 Favorito  
⭐ Destaque  
🎁 Ideia bônus  
🧩 Curiosidade  
💎 Premium  
🔮 Futuro  
🧘 Equilíbrio  
🌙 Noturno  
🌞 Diário  
🚨 Importante  

---

## ✨ Dicas de uso

- Para abrir o seletor de emojis:
  - **Windows:** `Win + .` ou `Win + ;`
  - **Mac:** `Ctrl + Cmd + Espaço`
- Adicione um **espaço após o emoji** no título da nota: ↆ