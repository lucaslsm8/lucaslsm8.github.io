# Personas – Meli Play

As personas fornecidas pelo briefing do Mercado Livre, representando diferentes necessidades e comportamentos.

---

## Carla, 21 anos

> "Tenho uma conversa comigo mesma no WhatsApp para anotar todos os filmes que meus colegas de trabalho me recomendam. Assim, posso assisti-los depois no Meli Play."

**Dor**: Precisa usar apps externos para salvar recomendações.

**Como vou resolver**: Sistema para salvar recomendações dentro do app.

---

## Virginia, 40 anos

> "Eu nunca me guio pelas recomendações de críticos de cinema ou pelas opiniões de pessoas que eu não conheço."

**Dor**: Não confia em recomendações de algoritmos ou críticos.

**Como vou resolver**: Rede familiar com recomendações apenas de pessoas próximas.

---

## Roberto, 60 anos

> "Tecnologia não é o meu forte. Quando abro o Meli Play, gostaria de ter um espaço com os conteúdos destacados pela minha família."

**Dor**: Quer simplicidade e recomendações da família em destaque.

**Como vou resolver**: Feed familiar simples e destacado na home.

---

## Andrés, 30 anos

> "Meu pai sempre esquece o nome das séries que quer me recomendar, e eu acabo tendo que procurar os títulos ou os atores no Google."

**Dor**: Dificuldade em lembrar nomes de títulos para recomendar.

**Como vou resolver**: Sistema de AI para busca por metadados e descrição de cenas.

---

← [[1 Desafio|Briefing]] | [[1 Pesquisa|Pesquisa →]]
