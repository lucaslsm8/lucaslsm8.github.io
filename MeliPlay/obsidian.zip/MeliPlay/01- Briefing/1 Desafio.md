# Briefing – Meli Play UX Challenge

Esse foi o briefing que recebi do Mercado Livre para o desafio de UX Design.

---

## O que é o UX Challenge?

O UX Challenge é a forma que o Mercado Livre usa para avaliar candidatos. Eles querem ver:
- Como eu tomo decisões
- Como aplico os princípios de design visual
- A lógica por trás do meu trabalho
- Como considero as necessidades do negócio e dos usuários

**Importante**: Todo o processo e entregáveis são meus. O Mercado Livre não vai usar minha solução em nenhum projeto.

---

## Contexto do Problema

### Sobre o Meli Play
O Meli Play é a plataforma de conteúdos grátis do Mercado Livre. Tem um catálogo com:
- Filmes
- Séries
- Documentários
- Conteúdo infantil
- Realities
- Outros conteúdos audiovisuais

### O Problema
No último mês, a frequência de uso caiu 4% comparado ao mês anterior.

O time de User Research entrou em contato com usuários e identificou alguns padrões nas respostas.

---

## Personas e Suas Dores

### Carla, 21 anos
> "Tenho uma conversa comigo mesma no WhatsApp para anotar todos os filmes que meus colegas de trabalho me recomendam. Assim, posso assisti-los depois no Meli Play."

**Dor**: Ela precisa usar outros apps para salvar recomendações.


---

### Virginia, 40 anos
> "Eu nunca me guio pelas recomendações de críticos de cinema ou pelas opiniões de pessoas que eu não conheço."

**Dor**: Não confia em recomendações de algoritmos ou críticos.

---

### Roberto, 60 anos
> "Tecnologia não é o meu forte. Quando abro o Meli Play, gostaria de ter um espaço com os conteúdos destacados pela minha família."

**Dor**: Quer algo simples com as recomendações da família em destaque.

---

### Andrés, 30 anos
> "Meu pai sempre esquece o nome das séries que quer me recomendar, e eu acabo tendo que procurar os títulos ou os atores no Google."

**Dor**: As pessoas esquecem os nomes dos títulos que querem recomendar.

---

## O Desafio

**Como podemos melhorar as recomendações de conteúdo entre amigos e familiares?**

Preciso criar uma proposta de melhoria inovadora e criativa para o Meli Play, focando na funcionalidade de "Recomendações de conteúdo de amigos e familiares" levando em conta os comentários dos usuários.

---

## O que Preciso Entregar

### Mínimo Necessário
- Pelo menos 1 fluxo em baixa fidelidade com as principais decisões funcionais
- No mínimo 3 telas diferentes em alta fidelidade
- Foco em visual design e fundamentos

### O que Esperam de Mim
- Mostrar que entendi o problema com uma solução focada no usuário
- Resolver os pontos de dor identificados
- Criar algo único e fácil de usar
- Entregável claro, objetivo e organizado
- Estar preparado para apresentar ao vivo

### Observações
- Posso me inspirar em outros apps de streaming
- Mas a ideia precisa ser original

---

**Próximo**: [[02-Research/Overview|Research →]]

---

**Documento original**: Mercado Livre - UX Challenge - Design.pdf
